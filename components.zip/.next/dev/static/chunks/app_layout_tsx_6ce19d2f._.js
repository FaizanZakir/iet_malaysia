(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8e325282._.css",
  "static/chunks/node_modules__pnpm_41fdb8c9._.js"
],
    source: "dynamic"
});
